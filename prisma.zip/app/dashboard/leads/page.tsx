"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

interface SetupStatus {
  informacoesOk: boolean; whatsappOk: boolean; vendedoresOk: boolean;
  clientesOk: boolean; nomeIAOk: boolean; posVendaOk: boolean;
  aniversarioOk: boolean; qualificacaoOk: boolean;
}

interface Lead {
  id: string;
  status: string;
  score: number;
  observacoes: string | null;
  vendedorId: string | null;
  empresaId: string;
  atualizadoEm: string;
  dataRecontato: string | null;
  cliente: { id: string; nome: string | null; telefone: string; email: string | null; dataNascimento: string | null; tags: string[] };
  empresa: { nome: string; instanciaWhatsapp: string };
}

interface Vendedor {
  id: string;
  nome: string;
  empresa: { nome: string };
}

const TAGS_PREDEFINIDAS = [
  { key: "indicacao",        label: "Indicação"        },
  { key: "anuncio",          label: "Anúncio"          },
  { key: "organico",         label: "Orgânico"         },
  { key: "VIP",              label: "VIP"              },
  { key: "Varejo",           label: "Varejo"           },
  { key: "Atacado",          label: "Atacado"          },
  { key: "Inadimplente",     label: "Inadimplente"     },
];

const colunas = [
  { status: "LEAD",                label: "Novos Leads",          short: "Novos",       hex: "#9ca3af" },
  { status: "AQUECIMENTO",         label: "Aquecimento",          short: "Aquecimento", hex: "#fb923c" },
  { status: "PRONTO_PARA_COMPRAR", label: "Pronto p/ Comprar",    short: "Pronto",      hex: "#fbbf24" },
  { status: "AGENDADO",            label: "Agendado / Orçamento", short: "Agendado",    hex: "#a78bfa" },
  { status: "NEGOCIACAO",          label: "Em Negociação",        short: "Negociação",  hex: "#60a5fa" },
  { status: "VENDA_REALIZADA",     label: "Venda Realizada",      short: "Vendido",     hex: "#34d399" },
  { status: "POS_VENDA",           label: "Pós-Venda",            short: "Pós-venda",   hex: "#c084fc" },
  { status: "FOLLOW_UP",           label: "Follow-up",            short: "Follow-up",   hex: "#22d3ee" },
  { status: "SEM_RESPOSTA",        label: "Sem Resposta",         short: "Sem resp.",   hex: "#fbbf24" },
  { status: "SEM_INTERESSE",       label: "Sem Interesse",        short: "Sem int.",    hex: "#fb7185" },
];

const todasOpcoes = [
  ...colunas,
  { status: "PERDIDO", label: "Perdido", hex: "#f87171" },
];

function parseDateLocal(iso: string): Date {
  // Extract date-only portion to avoid UTC-midnight timezone shift
  const [year, month, day] = iso.split("T")[0].split("-").map(Number);
  return new Date(year, month - 1, day);
}

function calcularIdade(dataNascimento: string): number {
  const nasc = parseDateLocal(dataNascimento);
  const hoje = new Date();
  let idade = hoje.getFullYear() - nasc.getFullYear();
  const m = hoje.getMonth() - nasc.getMonth();
  if (m < 0 || (m === 0 && hoje.getDate() < nasc.getDate())) idade--;
  return idade;
}

function fireLabel(score: number) {
  if (score === 0)   return { emoji: "·", label: "Sem score" };
  if (score < 25)    return { emoji: "🔥", label: "Morno" };
  if (score < 50)    return { emoji: "🔥🔥", label: "Quente" };
  if (score < 75)    return { emoji: "🔥🔥🔥", label: "Muito quente" };
  return             { emoji: "🔥🔥🔥🔥", label: "Em chamas!" };
}

function fireColor(score: number) {
  if (score === 0) return "#374151";
  if (score < 25)  return "#d97706";
  if (score < 50)  return "#f59e0b";
  if (score < 75)  return "#f97316";
  return "#ef4444";
}

export default function LeadsPage() {
  const router = useRouter();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [vendedores, setVendedores] = useState<Vendedor[]>([]);
  const [loading, setLoading] = useState(true);
  const [setup, setSetup] = useState<SetupStatus | null>(null);
  const [draggedId, setDraggedId] = useState<string | null>(null);
  const [dragOverCol, setDragOverCol] = useState<string | null>(null);
  const [editLead, setEditLead] = useState<Lead | null>(null);
  const [editForm, setEditForm] = useState({ status: "", observacoes: "", score: 0, vendedorId: "", dataRecontato: "", nomeCliente: "" });
  const [salvando, setSalvando] = useState(false);
  const [confirmandoExclusao, setConfirmandoExclusao] = useState(false);
  const [modoSelecao, setModoSelecao] = useState(false);
  const [selecionados, setSelecionados] = useState<string[]>([]);
  const [modalCampanha, setModalCampanha] = useState(false);
  const [tagSeletor, setTagSeletor] = useState(false);
  const [mensagemCampanha, setMensagemCampanha] = useState("");
  const [disparando, setDisparando] = useState(false);
  const [campanhaOk, setCampanhaOk] = useState(false);
  const [modalVenda, setModalVenda] = useState<Lead | null>(null);
  const [vendaForm, setVendaForm] = useState({ valor: "", descricao: "", vendedorId: "" });
  const [registrandoVenda, setRegistrandoVenda] = useState(false);
  const [vendaRegistrada, setVendaRegistrada] = useState(false);
  const [filtroStatus, setFiltroStatus] = useState("LEAD");
  const [filtroEmpresa, setFiltroEmpresa] = useState("");
  const [empresas, setEmpresas] = useState<{ id: string; nome: string }[]>([]);
  const [showWelcome, setShowWelcome] = useState(false);
  const kanbanRef = useRef<HTMLDivElement>(null);
  const topScrollRef = useRef<HTMLDivElement>(null);
  const topScrollInnerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const kanban = kanbanRef.current;
    const top = topScrollRef.current;
    const inner = topScrollInnerRef.current;
    if (!kanban || !top || !inner) return;

    // Sync scroll position
    const fromKanban = () => { top.scrollLeft = kanban.scrollLeft; };
    const fromTop = () => { kanban.scrollLeft = top.scrollLeft; };
    kanban.addEventListener("scroll", fromKanban);
    top.addEventListener("scroll", fromTop);

    // Keep mirror width = kanban scrollable width
    const updateWidth = () => { inner.style.width = kanban.scrollWidth + "px"; };
    updateWidth();
    requestAnimationFrame(updateWidth);
    const ro = new ResizeObserver(updateWidth);
    ro.observe(kanban);

    return () => {
      kanban.removeEventListener("scroll", fromKanban);
      top.removeEventListener("scroll", fromTop);
      ro.disconnect();
    };
  }, [loading]);

  useEffect(() => {
    fetch("/api/dashboard/setup")
      .then(r => r.json())
      .then(d => { if (d) setSetup(d); })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!setup) return;
    if (!setup.clientesOk && !setup.vendedoresOk) {
      const seen = typeof window !== "undefined" && localStorage.getItem("facilcrm_welcome_seen");
      if (seen) {
        router.replace("/dashboard/configuracoes");
      } else {
        setShowWelcome(true);
      }
    }
  }, [setup]);

  useEffect(() => {
    Promise.all([
      fetch("/api/leads").then((r) => r.json()),
      fetch("/api/vendedores?todos=true").then((r) => r.json()),
      fetch("/api/empresas").then((r) => r.json()),
    ])
      .then(([leadsData, vendedoresData, empresasData]) => {
        setLeads(leadsData);
        setVendedores(vendedoresData);
        setEmpresas(empresasData);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const moverLead = async (id: string, novoStatus: string) => {
    if (leads.find((l) => l.id === id)?.status === novoStatus) return;
    await fetch(`/api/leads/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: novoStatus }),
    });
    setLeads((prev) => prev.map((l) => (l.id === id ? { ...l, status: novoStatus } : l)));
  };

  const excluirLead = async () => {
    if (!editLead) return;
    setSalvando(true);
    await fetch(`/api/leads/${editLead.id}`, { method: "DELETE" });
    setLeads((prev) => prev.filter((l) => l.id !== editLead.id));
    setEditLead(null);
    setConfirmandoExclusao(false);
    setSalvando(false);
  };

  const abrirEdit = (lead: Lead) => {
    setEditLead(lead);
    setConfirmandoExclusao(false);
    setEditForm({ status: lead.status, observacoes: lead.observacoes ?? "", score: lead.score, vendedorId: lead.vendedorId ?? "", dataRecontato: lead.dataRecontato ? lead.dataRecontato.split("T")[0] : "", nomeCliente: lead.cliente.nome ?? "" });
  };

  const salvarEdit = async () => {
    if (!editLead) return;
    setSalvando(true);
    const [res] = await Promise.all([
      fetch(`/api/leads/${editLead.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: editForm.status, observacoes: editForm.observacoes, score: Number(editForm.score), vendedorId: editForm.vendedorId || null, dataRecontato: editForm.dataRecontato || null }),
      }),
      editForm.nomeCliente !== (editLead.cliente.nome ?? "")
        ? fetch(`/api/clientes/${editLead.cliente.id}`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nome: editForm.nomeCliente || null }),
          })
        : Promise.resolve(),
    ]);
    const updated = await res.json();
    const nomeAtualizado = editForm.nomeCliente !== (editLead.cliente.nome ?? "") ? editForm.nomeCliente || null : editLead.cliente.nome;
    setLeads((prev) => prev.map((l) => (l.id === editLead.id ? { ...l, ...updated, cliente: { ...l.cliente, nome: nomeAtualizado } } : l)));
    setEditLead(null);
    setSalvando(false);
  };

  const toggleSelecao = (id: string) => {
    setSelecionados((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const dispararCampanha = async () => {
    if (!mensagemCampanha.trim() || !selecionados.length) return;
    setDisparando(true);
    const lead = leads.find((l) => selecionados.includes(l.id));
    const res = await fetch("/api/campanhas", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        empresaId: lead?.empresaId,
        mensagem: mensagemCampanha,
        leadIds: selecionados,
      }),
    });
    setDisparando(false);
    if (res.ok) {
      setModalCampanha(false);
      setModoSelecao(false);
      setSelecionados([]);
      setMensagemCampanha("");
      setCampanhaOk(true);
      setTimeout(() => setCampanhaOk(false), 4000);
    }
  };

  const abrirModalVenda = (lead: Lead) => {
    setVendaForm({ valor: "", descricao: "", vendedorId: lead.vendedorId ?? "" });
    setModalVenda(lead);
    setEditLead(null);
  };

  const registrarVenda = async () => {
    if (!modalVenda || !vendaForm.vendedorId) return;
    setRegistrandoVenda(true);
    const res = await fetch("/api/vendas", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        leadId: modalVenda.id,
        vendedorId: vendaForm.vendedorId,
        valor: vendaForm.valor ? Number(vendaForm.valor.replace(",", ".")) : null,
        descricao: vendaForm.descricao || null,
      }),
    });
    if (res.ok) {
      setLeads((prev) =>
        prev.map((l) =>
          l.id === modalVenda.id
            ? { ...l, status: "VENDA_REALIZADA", vendedorId: vendaForm.vendedorId }
            : l
        )
      );
      setModalVenda(null);
      setVendaRegistrada(true);
      setTimeout(() => setVendaRegistrada(false), 4000);
    }
    setRegistrandoVenda(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full" style={{ background: "var(--bg)", color: "#64748b" }}>
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-sm">Carregando leads...</span>
        </div>
      </div>
    );
  }

  const fc = fireColor(editForm.score);
  const fl = fireLabel(editForm.score);

  const leadsVisiveis = filtroEmpresa ? leads.filter((l) => l.empresaId === filtroEmpresa) : leads;

  const setupDone  = setup ? Object.values(setup).filter(Boolean).length : 0;
  const setupTotal = setup ? Object.values(setup).length : 0;
  const setupPct   = setupTotal ? Math.round((setupDone / setupTotal) * 100) : 0;
  const allSetupDone   = setupDone === setupTotal;
  const hasStartedUsing = setup && (setup.clientesOk || setup.vendedoresOk);

  return (
    <div className="h-full overflow-y-auto" style={{ background: "var(--bg)" }}>

      {/* Setup banner — shows only when partially configured (not brand new, not done) */}
      {setup && hasStartedUsing && !allSetupDone && (
        <div className="px-6 pt-4 animate-fade-up">
          <a href="/dashboard/configuracoes"
            className="flex items-center justify-between gap-4 px-4 py-3 rounded-xl group transition-all"
            style={{ background: "rgba(99,102,241,.07)", border: "1px solid rgba(99,102,241,.16)" }}>
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-[11px] font-bold"
                style={{ background: "rgba(99,102,241,.18)", color: "#a5b4fc" }}>
                {setupPct}%
              </div>
              <div className="min-w-0">
                <p className="text-[13px] font-semibold" style={{ color: "var(--text)" }}>
                  Configure seu CRM — {setupDone} de {setupTotal} etapas concluídas
                </p>
                <div className="mt-1.5 h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,.07)", width: "180px", maxWidth: "100%" }}>
                  <div className="h-full rounded-full transition-all duration-700"
                    style={{ width: `${setupPct}%`, background: "linear-gradient(90deg,#6366f1,#818cf8)" }} />
                </div>
                <p className="text-[11px] font-medium mt-1.5" style={{ color: "#fbbf24" }}>
                  ⚠️ {!setup?.informacoesOk
                    ? "Sem as informações da empresa, seu Agente de IA não sabe o que vender."
                    : !setup?.whatsappOk
                      ? "WhatsApp desconectado — mensagens de clientes não estão chegando."
                      : "Configurações incompletas comprometem o desempenho do seu Agente de IA."}
                </p>
              </div>
            </div>
            <span className="flex-shrink-0 text-[11px] font-semibold px-2.5 py-1.5 rounded-lg transition-all"
              style={{ background: "rgba(99,102,241,.12)", color: "#a5b4fc", border: "1px solid rgba(99,102,241,.2)", whiteSpace: "nowrap" }}>
              Concluir →
            </span>
          </a>
        </div>
      )}

      <div className="p-6">
        {/* Header */}
        <div className="mb-6 animate-fade-up flex items-start justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold" style={{ color: "var(--text)" }}>Leads</h2>
            <p className="text-sm mt-1" style={{ color: "var(--muted-2)" }}>
              {leadsVisiveis.length} leads{filtroEmpresa ? " nesta empresa" : ""}
              <span className="hidden sm:inline"> · Arraste os cards para mover entre colunas</span>
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0 flex-wrap justify-end">
            {empresas.length > 1 && (
              <select
                value={filtroEmpresa}
                onChange={(e) => setFiltroEmpresa(e.target.value)}
                className="input-dark px-3 py-2 text-[13px] rounded-xl"
                style={{ minWidth: 0 }}
              >
                <option value="">Todas as empresas</option>
                {empresas.map((emp) => (
                  <option key={emp.id} value={emp.id}>{emp.nome}</option>
                ))}
              </select>
            )}
            {vendaRegistrada && (
              <span
                className="text-[12px] px-3 py-1.5 rounded-full font-semibold"
                style={{
                  background: "rgba(52,211,153,.1)",
                  color: "#34d399",
                  border: "1px solid rgba(52,211,153,.2)",
                }}
              >
                Venda registrada!
              </span>
            )}
            {campanhaOk && (
              <span
                className="text-[12px] px-3 py-1.5 rounded-full font-semibold"
                style={{
                  background: "rgba(52,211,153,.1)",
                  color: "#34d399",
                  border: "1px solid rgba(52,211,153,.2)",
                }}
              >
                Campanha criada!
              </span>
            )}
            <button
              onClick={() => {
                setModoSelecao((v) => !v);
                setSelecionados([]);
              }}
              className="px-4 py-2 rounded-xl text-[13px] font-medium transition-all"
              style={
                modoSelecao
                  ? {
                      background: "linear-gradient(135deg, #6366f1, #4f46e5)",
                      color: "white",
                      border: "1px solid transparent",
                    }
                  : {
                      background: "var(--input)",
                      border: "1px solid var(--border-2)",
                      color: "var(--muted)",
                    }
              }
            >
              {modoSelecao ? `Selecionar (${selecionados.length})` : "Selecionar"}
            </button>
          </div>
        </div>

        {/* ── Mobile: lista filtrada por status ── */}
        <div className="sm:hidden">
          {/* Chips de status */}
          <div className="flex gap-2 overflow-x-auto pb-3 -mx-6 px-6 mb-4">
            {colunas.map((col) => {
              const count = leadsVisiveis.filter(l => l.status === col.status).length;
              const ativo = filtroStatus === col.status;
              return (
                <button key={col.status} onClick={() => setFiltroStatus(col.status)}
                  className="flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-semibold transition-all"
                  style={ativo
                    ? { background: `${col.hex}22`, color: col.hex, border: `1.5px solid ${col.hex}55` }
                    : { background: "var(--card)", color: "var(--muted-2)", border: "1px solid var(--border)" }
                  }>
                  {col.short}
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{ background: ativo ? `${col.hex}33` : "var(--card-2)", color: ativo ? col.hex : "var(--muted-3)" }}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Lista de leads do status selecionado */}
          {(() => {
            const col = colunas.find(c => c.status === filtroStatus)!;
            const leadsColuna = leadsVisiveis.filter(l => l.status === filtroStatus);
            return (
              <div className="space-y-2 pb-4">
                {leadsColuna.length === 0 ? (
                  <div className="py-12 text-center text-[13px] rounded-2xl"
                    style={{ color: "var(--muted-3)", border: "1px dashed var(--border)" }}>
                    Nenhum lead em {col.label}
                  </div>
                ) : leadsColuna.map((lead) => {
                  const sc = fireColor(lead.score);
                  const fl2 = fireLabel(lead.score);
                  const isSelected = selecionados.includes(lead.id);
                  return (
                    <div key={lead.id}
                      onClick={() => modoSelecao ? toggleSelecao(lead.id) : abrirEdit(lead)}
                      className="rounded-xl p-3.5 transition-all relative"
                      style={{
                        background: isSelected ? "rgba(99,102,241,.12)" : "var(--card)",
                        border: isSelected ? "1px solid rgba(99,102,241,.35)" : "1px solid var(--border)",
                        borderLeft: `3px solid ${col.hex}`,
                        cursor: "pointer",
                      }}>
                      {modoSelecao && (
                        <div className="absolute top-3 right-3 w-5 h-5 rounded-full flex items-center justify-center"
                          style={{
                            background: isSelected ? "#6366f1" : "var(--card-3)",
                            border: isSelected ? "none" : "1px solid var(--border-2)",
                          }}>
                          {isSelected && <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                        </div>
                      )}
                      <div className={`flex items-start justify-between gap-2${modoSelecao ? " pr-7" : ""}`}>
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold text-[14px] leading-tight" style={{ color: "var(--text)" }}>
                            {lead.cliente.nome ?? lead.cliente.telefone}
                          </p>
                          {lead.cliente.nome && (
                            <p className="text-[12px] font-mono mt-0.5" style={{ color: "var(--muted-2)" }}>{lead.cliente.telefone}</p>
                          )}
                          <p className="text-[11px] mt-0.5" style={{ color: "var(--muted-3)" }}>{lead.empresa.nome}</p>
                          {lead.observacoes && (
                            <p className="text-[12px] mt-1.5 line-clamp-1" style={{ color: "var(--muted-2)" }}>{lead.observacoes}</p>
                          )}
                        </div>
                        {!modoSelecao && (
                          <button onClick={(e) => { e.stopPropagation(); abrirEdit(lead); }}
                            className="text-[11px] px-2.5 py-1.5 rounded-lg font-semibold flex-shrink-0"
                            style={{ background: "rgba(99,102,241,.08)", color: "#a5b4fc", border: "1px solid rgba(99,102,241,.15)" }}>
                            Editar
                          </button>
                        )}
                      </div>
                      {lead.score > 0 && (
                        <div className="mt-2 flex items-center gap-1.5">
                          <div className="flex-1 h-1.5 rounded-full" style={{ background: "var(--card-3)" }}>
                            <div className="h-full rounded-full" style={{ width: `${lead.score}%`, background: `linear-gradient(90deg, ${sc}, ${sc}bb)` }} />
                          </div>
                          <span className="text-[10px]">{fl2.emoji}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>

        {/* ── Desktop: Kanban ── */}
        {/* Barra de rolagem superior sincronizada */}
        <div
          ref={topScrollRef}
          className="hidden sm:block"
          style={{ overflowX: "scroll", overflowY: "hidden", height: 20 }}
        >
          <div ref={topScrollInnerRef} style={{ height: 1 }} />
        </div>
        <div ref={kanbanRef} className="hidden sm:flex gap-3 overflow-x-auto pb-4">
          {colunas.map((col) => {
            const leadsColuna = leadsVisiveis.filter((l) => l.status === col.status);
            const isOver = dragOverCol === col.status;
            return (
              <div
                key={col.status}
                className="flex-shrink-0 w-60"
                onDragOver={(e) => { e.preventDefault(); setDragOverCol(col.status); }}
                onDragLeave={() => setDragOverCol(null)}
                onDrop={() => {
                  if (draggedId) moverLead(draggedId, col.status);
                  setDraggedId(null);
                  setDragOverCol(null);
                }}
              >
                {/* Column header */}
                <div
                  className="rounded-xl px-3 py-2.5 mb-2 flex justify-between items-center"
                  style={{
                    background: isOver
                      ? `${col.hex}18`
                      : "var(--card)",
                    borderTop: `2px solid ${col.hex}`,
                    border: isOver ? `1px solid ${col.hex}55` : "1px solid var(--border)",
                    borderTopWidth: "2px",
                  }}
                >
                  <span className="text-[12px] font-semibold" style={{ color: col.hex }}>
                    {col.label}
                  </span>
                  <span
                    className="text-[11px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{ background: `${col.hex}22`, color: col.hex }}
                  >
                    {leadsColuna.length}
                  </span>
                </div>

                {/* Cards */}
                <div
                  className="space-y-2 min-h-[60px] rounded-xl p-1 transition-all"
                  style={{
                    background: isOver ? `${col.hex}08` : "transparent",
                    outline: isOver ? `1.5px dashed ${col.hex}55` : "none",
                  }}
                >
                  {leadsColuna.map((lead) => {
                    const sc = fireColor(lead.score);
                    const fl2 = fireLabel(lead.score);
                    const isSelected = selecionados.includes(lead.id);
                    return (
                      <div
                        key={lead.id}
                        draggable={!modoSelecao}
                        onDragStart={() => !modoSelecao && setDraggedId(lead.id)}
                        onDragEnd={() => { setDraggedId(null); setDragOverCol(null); }}
                        onClick={() => modoSelecao && toggleSelecao(lead.id)}
                        className="rounded-xl p-3 select-none transition-all glass-hover relative"
                        style={{
                          background: isSelected
                            ? "rgba(99,102,241,.12)"
                            : "var(--card)",
                          border: isSelected
                            ? "1px solid rgba(99,102,241,.35)"
                            : "1px solid var(--border)",
                          opacity: draggedId === lead.id ? 0.3 : 1,
                          cursor: modoSelecao ? "pointer" : "grab",
                        }}
                      >
                        {/* Selection checkbox */}
                        {modoSelecao && (
                          <div
                            className="absolute top-2.5 left-2.5 w-4 h-4 rounded flex items-center justify-center flex-shrink-0"
                            style={{
                              background: isSelected
                                ? "#6366f1"
                                : "var(--card-3)",
                              border: isSelected
                                ? "1px solid #6366f1"
                                : "1px solid var(--border-2)",
                            }}
                          >
                            {isSelected && (
                              <svg className="w-2.5 h-2.5 text-white" fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                              </svg>
                            )}
                          </div>
                        )}
                        <div className={`flex justify-between items-start gap-1${modoSelecao ? " pl-5" : ""}`}>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-[13px] leading-tight truncate" style={{ color: "var(--text)" }}>
                              {lead.cliente.nome ?? lead.cliente.telefone}
                            </p>
                            {lead.cliente.nome && (
                              <p className="text-[11px] truncate mt-0.5" style={{ color: "var(--muted-2)" }}>
                                {lead.cliente.telefone}
                              </p>
                            )}
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); abrirEdit(lead); }}
                            className="text-[15px] flex-shrink-0 opacity-40 hover:opacity-100 transition-opacity"
                            title="Editar lead"
                          >
                            ✏️
                          </button>
                        </div>

                        <p className="text-[11px] mt-1 truncate" style={{ color: "var(--muted-2)" }}>
                          {lead.empresa.nome}
                        </p>

                        {lead.observacoes && (
                          <p className="text-[11px] mt-1.5 line-clamp-2 leading-tight" style={{ color: "var(--muted-2)" }}>
                            {lead.observacoes}
                          </p>
                        )}

                        {lead.score > 0 && (
                          <div className="mt-2 flex items-center gap-1.5">
                            <div
                              className="flex-1 h-1.5 rounded-full"
                              style={{ background: "var(--card-3)" }}
                            >
                              <div
                                className="h-full rounded-full transition-all"
                                style={{
                                  width: `${lead.score}%`,
                                  background: `linear-gradient(90deg, ${sc}, ${sc}bb)`,
                                  boxShadow: `0 0 6px ${sc}88`,
                                }}
                              />
                            </div>
                            <span className="text-[10px]">{fl2.emoji}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}

                  {leadsColuna.length === 0 && (
                    <div
                      className="text-center py-8 text-[11px] rounded-xl border border-dashed transition-all"
                      style={{
                        borderColor: isOver ? `${col.hex}66` : "var(--border)",
                        color: isOver ? col.hex : "rgba(148,163,184,.25)",
                        background: isOver ? `${col.hex}06` : "transparent",
                      }}
                    >
                      {isOver ? "Soltar aqui" : "Nenhum lead"}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Tag selector dropdown */}
      {modoSelecao && tagSeletor && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 rounded-2xl p-4 animate-fade-up" style={{ background: "var(--modal)", border: "1px solid var(--border-2)", boxShadow: "0 16px 40px rgba(0,0,0,.6)", minWidth: 280 }}>
          <p className="text-[11px] font-semibold mb-3" style={{ color: "var(--muted)" }}>SELECIONAR LEADS POR TAG</p>
          <div className="flex flex-wrap gap-2">
            {TAGS_PREDEFINIDAS.map(t => {
              const count = leads.filter(l => l.cliente.tags?.includes(t.key)).length;
              return (
                <button
                  key={t.key}
                  disabled={count === 0}
                  onClick={() => {
                    setSelecionados(leads.filter(l => l.cliente.tags?.includes(t.key)).map(l => l.id));
                    setTagSeletor(false);
                  }}
                  className="px-3 py-1.5 rounded-full text-[12px] font-semibold transition-all disabled:opacity-30"
                  style={{ background: "var(--card)", border: "1px solid var(--border)", color: "var(--muted-2)" }}
                >
                  {t.label} {count > 0 ? `(${count})` : "(0)"}
                </button>
              );
            })}
          </div>
          <button onClick={() => setTagSeletor(false)} className="mt-3 text-[11px]" style={{ color: "var(--muted-3)" }}>Fechar</button>
        </div>
      )}

      {/* Floating campaign bar */}
      {modoSelecao && selecionados.length > 0 && (
        <div
          className="fixed bottom-4 left-4 right-4 sm:left-1/2 sm:right-auto sm:w-auto sm:-translate-x-1/2 z-40 flex items-center justify-between sm:justify-start gap-3 sm:gap-4 px-4 sm:px-5 py-3 rounded-2xl animate-fade-up"
          style={{
            background: "linear-gradient(145deg, #13131f, #0d0d18)",
            border: "1px solid rgba(99,102,241,.3)",
            boxShadow: "0 8px 40px rgba(0,0,0,.6), 0 0 0 1px rgba(99,102,241,.1)",
          }}
        >
          <span className="text-[13px] font-semibold" style={{ color: "#a5b4fc" }}>
            {selecionados.length} lead{selecionados.length !== 1 ? "s" : ""} selecionado{selecionados.length !== 1 ? "s" : ""}
          </span>
          <button
            onClick={() => setTagSeletor(v => !v)}
            className="text-[12px] px-3 py-1.5 rounded-xl font-semibold transition-all"
            style={{ background: "rgba(255,255,255,.08)", border: "1px solid rgba(255,255,255,.12)", color: "var(--muted-2)" }}
          >
            🏷 Por tag
          </button>
          <button
            onClick={() => { setSelecionados([]); }}
            className="text-[12px] transition-colors"
            style={{ color: "var(--muted-3)" }}
          >
            Limpar
          </button>
          <button
            onClick={() => setModalCampanha(true)}
            className="btn-primary px-4 py-2 text-[13px]"
          >
            Disparar Campanha
          </button>
        </div>
      )}

      {/* Campaign modal */}
      {modalCampanha && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: "rgba(0,0,0,.75)", backdropFilter: "blur(8px)" }}
        >
          <div
            className="w-full max-w-md rounded-2xl overflow-hidden animate-fade-up"
            style={{
              background: "var(--modal)",
              border: "1px solid var(--border-2)",
              boxShadow: "0 24px 60px var(--shadow), 0 8px 20px var(--shadow)",
            }}
          >
            <div className="px-5 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
              <h3 className="font-bold text-[15px]" style={{ color: "var(--text)" }}>Disparar Campanha</h3>
              <p className="text-[12px] mt-0.5" style={{ color: "var(--muted-2)" }}>
                {selecionados.length} lead{selecionados.length !== 1 ? "s" : ""} selecionado{selecionados.length !== 1 ? "s" : ""}
              </p>
            </div>

            <div className="px-5 py-4 space-y-4">
              <div
                className="px-3 py-2.5 rounded-xl text-[12px]"
                style={{
                  background: "rgba(251,191,36,.06)",
                  border: "1px solid rgba(251,191,36,.15)",
                  color: "#fbbf24",
                }}
              >
                ⚡ As mensagens serão enviadas com espaçamento anti-spam automático.
              </div>
              <div>
                <label
                  className="block text-[11px] font-semibold mb-1.5"
                  style={{ color: "var(--muted)" }}
                >
                  MENSAGEM
                </label>
                <textarea
                  rows={4}
                  value={mensagemCampanha}
                  onChange={(e) => setMensagemCampanha(e.target.value)}
                  placeholder="Digite a mensagem da campanha... Use {nome} para personalizar."
                  className="w-full input-dark px-3 py-2.5 text-[13px] resize-none"
                  autoFocus
                />
                <p className="text-[11px] mt-1" style={{ color: "var(--muted-3)" }}>
                  Use {"{nome}"} para personalizar com o nome do cliente.
                </p>
              </div>
            </div>

            <div
              className="px-5 py-4 flex gap-2 justify-end"
              style={{ borderTop: "1px solid var(--border)" }}
            >
              <button
                onClick={() => { setModalCampanha(false); setMensagemCampanha(""); }}
                className="px-4 py-2 rounded-xl text-[13px] font-medium"
                style={{
                  background: "var(--card-2)",
                  border: "1px solid var(--border-2)",
                  color: "#94a3b8",
                }}
              >
                Cancelar
              </button>
              <button
                onClick={dispararCampanha}
                disabled={disparando || !mensagemCampanha.trim()}
                className="btn-primary px-5 py-2 text-[13px] disabled:opacity-50"
              >
                {disparando ? "Disparando..." : "Disparar"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Venda modal */}
      {modalVenda && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: "rgba(0,0,0,.75)", backdropFilter: "blur(8px)" }}
        >
          <div
            className="w-full max-w-sm rounded-2xl overflow-hidden animate-fade-up"
            style={{
              background: "var(--modal)",
              border: "1px solid var(--border-2)",
              boxShadow: "0 24px 60px var(--shadow), 0 8px 20px var(--shadow)",
            }}
          >
            <div className="px-5 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
              <h3 className="font-bold text-[15px]" style={{ color: "#34d399" }}>Registrar Venda</h3>
              <p className="text-[12px] mt-0.5" style={{ color: "var(--muted-2)" }}>
                {modalVenda.cliente.nome ?? modalVenda.cliente.telefone} · {modalVenda.empresa.nome}
              </p>
            </div>

            <div className="px-5 py-4 space-y-4">
              <div>
                <label className="block text-[11px] font-semibold mb-1.5" style={{ color: "var(--muted)" }}>
                  VALOR DA VENDA (R$)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={vendaForm.valor}
                  onChange={(e) => setVendaForm((p) => ({ ...p, valor: e.target.value }))}
                  placeholder="0,00"
                  className="w-full input-dark px-3 py-2.5 text-[13px]"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold mb-1.5" style={{ color: "var(--muted)" }}>
                  VENDEDOR RESPONSÁVEL
                </label>
                <select
                  value={vendaForm.vendedorId}
                  onChange={(e) => setVendaForm((p) => ({ ...p, vendedorId: e.target.value }))}
                  className="w-full input-dark px-3 py-2.5 text-[13px]"
                >
                  <option value="">Selecione um vendedor</option>
                  {vendedores.map((v) => (
                    <option key={v.id} value={v.id}>{v.nome} ({v.empresa.nome})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-semibold mb-1.5" style={{ color: "var(--muted)" }}>
                  DESCRIÇÃO (opcional)
                </label>
                <input
                  type="text"
                  value={vendaForm.descricao}
                  onChange={(e) => setVendaForm((p) => ({ ...p, descricao: e.target.value }))}
                  placeholder="Ex: 2x produto A + frete"
                  className="w-full input-dark px-3 py-2.5 text-[13px]"
                />
              </div>
            </div>

            <div
              className="px-5 py-4 flex gap-2 justify-end"
              style={{ borderTop: "1px solid var(--border)" }}
            >
              <button
                onClick={() => setModalVenda(null)}
                className="px-4 py-2 rounded-xl text-[13px] font-medium"
                style={{
                  background: "var(--card-2)",
                  border: "1px solid var(--border-2)",
                  color: "#94a3b8",
                }}
              >
                Cancelar
              </button>
              <button
                onClick={registrarVenda}
                disabled={registrandoVenda || !vendaForm.vendedorId}
                className="px-5 py-2 rounded-xl text-[13px] font-semibold disabled:opacity-50 transition-all"
                style={{
                  background: "linear-gradient(135deg, #34d399, #059669)",
                  color: "white",
                  border: "none",
                }}
              >
                {registrandoVenda ? "Registrando..." : "Confirmar Venda"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Welcome modal — brand-new accounts */}
      {showWelcome && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: "rgba(0,0,0,.88)", backdropFilter: "blur(10px)" }}>
          <div className="w-full max-w-lg rounded-2xl overflow-hidden animate-fade-up"
            style={{ background: "var(--modal)", border: "1px solid var(--border-2)", boxShadow: "0 32px 80px rgba(0,0,0,.7)" }}>

            {/* Header */}
            <div className="px-6 py-5"
              style={{ borderBottom: "1px solid var(--border)", background: "linear-gradient(135deg,rgba(99,102,241,.12),rgba(79,70,229,.03))" }}>
              <div className="flex items-center gap-3 mb-1.5">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                  style={{ background: "rgba(99,102,241,.2)" }}>
                  🎉
                </div>
                <h2 className="text-[19px] font-black" style={{ color: "var(--text)" }}>Bem-vindo ao FácilCRM!</h2>
              </div>
              <p className="text-[13px]" style={{ color: "var(--muted-2)" }}>
                Você está a <strong style={{ color: "var(--text)" }}>3 passos</strong> de ativar o atendimento automático da sua empresa.
              </p>
            </div>

            {/* Red warning block */}
            <div className="px-6 py-3.5 text-[12.5px] font-semibold leading-snug"
              style={{ background: "rgba(239,68,68,.09)", borderBottom: "1px solid rgba(239,68,68,.14)", color: "#f87171" }}>
              ⚠️ Sem completar estas etapas, seu Agente de IA vai atender clientes com respostas genéricas e erradas — e isso prejudica a reputação da sua empresa.
            </div>

            {/* Steps */}
            <div className="px-6 py-5 space-y-3">
              {[
                {
                  icon: "🏢",
                  title: "Informações da Empresa",
                  desc: "Produtos, preços, horários e diferenciais. É exatamente o que a IA vai falar para os seus clientes.",
                },
                {
                  icon: "📱",
                  title: "WhatsApp Conectado",
                  desc: "Sem conexão, a IA não recebe mensagens. Nenhum atendimento automático acontece.",
                },
                {
                  icon: "👤",
                  title: "Pelo menos 1 Vendedor",
                  desc: "O CRM precisa de um responsável para receber os leads qualificados pela IA.",
                },
              ].map((step, i) => (
                <div key={i} className="flex items-start gap-3 p-3.5 rounded-xl"
                  style={{ background: "rgba(255,255,255,.02)", border: "1px solid var(--border)" }}>
                  <div className="text-[22px] flex-shrink-0 mt-[1px]">{step.icon}</div>
                  <div>
                    <p className="text-[13px] font-bold" style={{ color: "var(--text)" }}>{step.title}</p>
                    <p className="text-[12px] mt-0.5 leading-snug" style={{ color: "var(--muted-2)" }}>{step.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer CTAs */}
            <div className="px-6 py-4 flex flex-col sm:flex-row gap-2 items-center" style={{ borderTop: "1px solid var(--border)" }}>
              <button
                onClick={() => {
                  localStorage.setItem("facilcrm_welcome_seen", "1");
                  router.replace("/dashboard/configuracoes");
                }}
                className="btn-primary py-3 text-[14px] font-bold w-full sm:flex-1"
              >
                Configurar agora →
              </button>
              <button
                onClick={() => {
                  localStorage.setItem("facilcrm_welcome_seen", "1");
                  setShowWelcome(false);
                }}
                className="text-[12px] px-4 py-2 rounded-xl transition-colors w-full sm:w-auto text-center"
                style={{ color: "var(--muted-3)", background: "var(--card-2)", border: "1px solid var(--border)" }}
              >
                Explorar primeiro
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit modal */}
      {editLead && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: "rgba(0,0,0,.75)", backdropFilter: "blur(8px)" }}
        >
          <div
            className="w-full max-w-md rounded-2xl flex flex-col animate-fade-up"
            style={{
              background: "var(--modal)",
              border: "1px solid var(--border-2)",
              boxShadow: "0 24px 60px var(--shadow), 0 8px 20px var(--shadow)",
              maxHeight: "calc(100vh - 2rem)",
            }}
          >
            {/* Modal header */}
            <div className="px-5 py-4 flex-shrink-0" style={{ borderBottom: "1px solid var(--border)" }}>
              <h3 className="font-bold text-[15px]" style={{ color: "var(--text)" }}>Editar Lead</h3>
              <p className="text-[12px] mt-0.5" style={{ color: "var(--muted-2)" }}>
                {editLead.cliente.nome ?? editLead.cliente.telefone} · {editLead.empresa.nome}
              </p>
            </div>

            <div className="px-5 py-4 space-y-4 overflow-y-auto flex-1">
              {/* Dados do cliente */}
              <div
                className="rounded-xl p-3 space-y-2"
                style={{ background: "var(--card)", border: "1px solid var(--border)" }}
              >
                <p className="text-[10px] font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--muted)" }}>
                  Dados do Cliente
                </p>
                {/* Nome */}
                <div className="flex items-center gap-2">
                  <span className="text-[13px]" style={{ color: "var(--muted-2)" }}>👤</span>
                  <input
                    type="text"
                    value={editForm.nomeCliente}
                    onChange={(e) => setEditForm((p) => ({ ...p, nomeCliente: e.target.value }))}
                    placeholder="Nome do cliente"
                    className="flex-1 input-dark px-2 py-1 text-[13px] rounded-lg"
                  />
                </div>
                {/* Telefone clicável WhatsApp */}
                <div className="flex items-center gap-2 text-[13px]">
                  <span style={{ color: "var(--muted-2)" }}>📱</span>
                  <a
                    href={`https://wa.me/${editLead.cliente.telefone}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-medium transition-colors"
                    style={{ color: "#25D366" }}
                    onMouseEnter={(e) => ((e.target as HTMLElement).style.textDecoration = "underline")}
                    onMouseLeave={(e) => ((e.target as HTMLElement).style.textDecoration = "none")}
                  >
                    {editLead.cliente.telefone}
                  </a>
                </div>
                {/* Email */}
                {editLead.cliente.email && (
                  <div className="flex items-center gap-2 text-[13px]">
                    <span style={{ color: "var(--muted-2)" }}>✉️</span>
                    <span style={{ color: "var(--text)" }}>{editLead.cliente.email}</span>
                  </div>
                )}
                {/* Aniversário + Idade */}
                {editLead.cliente.dataNascimento && (
                  <div className="flex items-center gap-2 text-[13px]">
                    <span style={{ color: "var(--muted-2)" }}>🎂</span>
                    <span style={{ color: "var(--text)" }}>
                      {parseDateLocal(editLead.cliente.dataNascimento).toLocaleDateString("pt-BR")}
                      <span className="ml-2 text-[11px]" style={{ color: "var(--muted-2)" }}>
                        ({calcularIdade(editLead.cliente.dataNascimento)} anos)
                      </span>
                    </span>
                  </div>
                )}
              </div>

              {/* Status */}
              <div>
                <label className="block text-[11px] font-semibold mb-1.5" style={{ color: "var(--muted)" }}>
                  STATUS
                </label>
                <select
                  value={editForm.status}
                  onChange={(e) => setEditForm((p) => ({ ...p, status: e.target.value }))}
                  className="w-full input-dark px-3 py-2.5 text-[13px]"
                >
                  {todasOpcoes.map((c) => (
                    <option key={c.status} value={c.status}>{c.label}</option>
                  ))}
                </select>
              </div>

              {/* Score fire bar */}
              <div>
                <label className="block text-[11px] font-semibold mb-2" style={{ color: "var(--muted)" }}>
                  SCORE DO LEAD
                </label>
                <div
                  className="rounded-xl p-3"
                  style={{ background: "var(--card)", border: "1px solid var(--border)" }}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xl w-16 text-center leading-none">{fl.emoji}</span>
                    <div className="flex-1">
                      <input
                        type="range"
                        min={0}
                        max={100}
                        step={5}
                        value={editForm.score}
                        onChange={(e) => setEditForm((p) => ({ ...p, score: Number(e.target.value) }))}
                        className="w-full h-2 rounded-full appearance-none cursor-pointer"
                        style={{
                          background: `linear-gradient(90deg, ${fc} ${editForm.score}%, var(--border-2) ${editForm.score}%)`,
                          accentColor: fc,
                        }}
                      />
                    </div>
                    <span
                      className="text-[15px] font-bold w-8 text-right tabular-nums"
                      style={{ color: fc }}
                    >
                      {editForm.score}
                    </span>
                  </div>
                  <div className="flex justify-between text-[10px] px-1" style={{ color: "var(--muted-3)" }}>
                    <span>Frio</span>
                    <span className="font-medium" style={{ color: fc }}>{fl.label}</span>
                    <span>Em chamas</span>
                  </div>
                </div>
              </div>

              {/* Observações */}
              <div>
                <label className="block text-[11px] font-semibold mb-1.5" style={{ color: "var(--muted)" }}>
                  OBSERVAÇÕES
                </label>
                <textarea
                  rows={3}
                  value={editForm.observacoes}
                  onChange={(e) => setEditForm((p) => ({ ...p, observacoes: e.target.value }))}
                  placeholder="Notas sobre este lead..."
                  className="w-full input-dark px-3 py-2.5 text-[13px] resize-none"
                />
              </div>

              {/* Vendedor */}
              <div>
                <label className="block text-[11px] font-semibold mb-1.5" style={{ color: "var(--muted)" }}>
                  VENDEDOR
                </label>
                <select
                  value={editForm.vendedorId}
                  onChange={(e) => setEditForm((p) => ({ ...p, vendedorId: e.target.value }))}
                  className="w-full input-dark px-3 py-2.5 text-[13px]"
                >
                  <option value="">Sem vendedor</option>
                  {vendedores.map((v) => (
                    <option key={v.id} value={v.id}>{v.nome} ({v.empresa.nome})</option>
                  ))}
                </select>
              </div>

              {/* Data de recontato */}
              <div>
                <label className="block text-[11px] font-semibold mb-1.5" style={{ color: "var(--muted)" }}>
                  RECONTATO AGENDADO
                </label>
                <input
                  type="date"
                  value={editForm.dataRecontato}
                  onChange={(e) => setEditForm((p) => ({ ...p, dataRecontato: e.target.value }))}
                  className="w-full input-dark px-3 py-2.5 text-[13px]"
                />
                <p className="text-[11px] mt-1" style={{ color: "var(--muted-3)" }}>
                  IA liga nesta data automaticamente. Deixe vazio para não agendar.
                </p>
              </div>
            </div>

            {/* Modal footer */}
            <div className="px-5 py-4 flex-shrink-0" style={{ borderTop: "1px solid var(--border)" }}>
              {/* Registrar Venda — full width no mobile */}
              {["PRONTO_PARA_COMPRAR", "NEGOCIACAO", "AGENDADO"].includes(editForm.status) && editLead && (
                <button
                  onClick={() => abrirModalVenda(editLead!)}
                  className="w-full sm:hidden mb-3 py-2.5 rounded-xl text-[13px] font-semibold transition-all"
                  style={{ background: "rgba(52,211,153,.12)", border: "1px solid rgba(52,211,153,.3)", color: "#34d399" }}
                >
                  Registrar Venda
                </button>
              )}
              <div className="flex gap-2 justify-between items-center">
                <div>
                  {!confirmandoExclusao ? (
                    <button
                      onClick={() => setConfirmandoExclusao(true)}
                      className="text-[12px] transition-colors"
                      style={{ color: "rgba(248,113,113,.6)" }}
                      onMouseEnter={(e) => ((e.target as HTMLElement).style.color = "#f87171")}
                      onMouseLeave={(e) => ((e.target as HTMLElement).style.color = "rgba(248,113,113,.6)")}
                    >
                      Excluir lead
                    </button>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] font-medium" style={{ color: "#f87171" }}>Confirmar?</span>
                      <button
                        onClick={excluirLead}
                        disabled={salvando}
                        className="text-[11px] font-semibold px-3 py-1.5 rounded-lg disabled:opacity-50"
                        style={{ background: "rgba(239,68,68,.15)", color: "#f87171", border: "1px solid rgba(239,68,68,.3)" }}
                      >
                        Excluir
                      </button>
                      <button onClick={() => setConfirmandoExclusao(false)} className="text-[11px]" style={{ color: "var(--muted-2)" }}>
                        Não
                      </button>
                    </div>
                  )}
                </div>
                <div className="flex gap-2 items-center">
                  {["PRONTO_PARA_COMPRAR", "NEGOCIACAO", "AGENDADO"].includes(editForm.status) && editLead && (
                    <button
                      onClick={() => abrirModalVenda(editLead!)}
                      className="hidden sm:block px-4 py-2 rounded-xl text-[13px] font-semibold transition-all"
                      style={{ background: "rgba(52,211,153,.12)", border: "1px solid rgba(52,211,153,.3)", color: "#34d399" }}
                    >
                      Registrar Venda
                    </button>
                  )}
                  <button
                    onClick={() => { setEditLead(null); setConfirmandoExclusao(false); }}
                    className="px-4 py-2 rounded-xl text-[13px] font-medium transition-all"
                    style={{ background: "var(--card-2)", border: "1px solid var(--border-2)", color: "#94a3b8" }}
                  >
                    Cancelar
                  </button>
                  <button onClick={salvarEdit} disabled={salvando} className="btn-primary px-4 py-2 text-[13px] disabled:opacity-50">
                    {salvando ? "Salvando..." : "Salvar"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
