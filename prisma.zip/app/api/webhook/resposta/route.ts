import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { LeadStatus } from "@prisma/client";

export async function POST(req: Request) {
  const body = await req.json();
  const { conversaId, leadId, resposta, novoStatus, observacoes, notificarVendedor, notificarGerente, dataRecontato, score, memoriaCliente, clienteId } = body;

  if (!conversaId || !resposta) {
    return NextResponse.json({ ok: false, motivo: "campos obrigatorios ausentes" });
  }

  await prisma.mensagem.create({
    data: { conversaId, conteudo: resposta, direcao: "SAIDA" },
  });

  await prisma.conversa.update({
    where: { id: conversaId },
    data: {
      ultimaMensagem: resposta,
      ultimaAtividade: new Date(),
      processando: false,
      processandoEm: null,
    },
  });

  // Status hierarchy — AI cannot downgrade leads that reached AGENDADO or beyond
  const statusOrder: LeadStatus[] = [
    "LEAD", "AQUECIMENTO", "PRONTO_PARA_COMPRAR", "AGENDADO",
    "NEGOCIACAO", "VENDA_REALIZADA", "POS_VENDA",
  ];
  const terminalStatus: LeadStatus[] = ["PERDIDO", "SEM_INTERESSE", "SEM_RESPOSTA", "FOLLOW_UP"];

  if (leadId && (novoStatus || observacoes)) {
    let statusToApply: LeadStatus | undefined;
    if (novoStatus) {
      const current = await prisma.lead.findUnique({ where: { id: leadId }, select: { status: true } });
      const currentIdx = current ? statusOrder.indexOf(current.status as LeadStatus) : -1;
      const newIdx = statusOrder.indexOf(novoStatus as LeadStatus);
      const isTerminal = terminalStatus.includes(novoStatus as LeadStatus);
      // Only apply if it's a promotion, a terminal status, or current isn't in the ordered list
      if (isTerminal || newIdx === -1 || currentIdx === -1 || newIdx > currentIdx) {
        statusToApply = novoStatus as LeadStatus;
      }
    }
    await prisma.lead.update({
      where: { id: leadId },
      data: {
        ...(statusToApply && { status: statusToApply }),
        ...(observacoes && { observacoes }),
        ...(score !== undefined && { score: Number(score) }),
        ...(dataRecontato !== undefined && {
          dataRecontato: dataRecontato ? new Date(dataRecontato) : null,
        }),
      },
    });
  }

  // Atualizar memória do cliente se informada
  if (clienteId && memoriaCliente) {
    await prisma.cliente.update({
      where: { id: clienteId },
      data: { memoriaCliente },
    }).catch(() => null);
  }

  let vendedor = null;
  let gerente = null;
  let aprendizados: string | null = null;

  if (leadId) {
    const lead = await prisma.lead.findUnique({
      where: { id: leadId },
      include: { empresa: { select: { aprendizados: true } } },
    });
    if (lead) {
      aprendizados = lead.empresa.aprendizados ?? null;
      if (notificarVendedor) {
        if (lead.vendedorId) {
          // Lead já tem vendedor — notifica ele diretamente (ex: acompanhamento, NF, entrega)
          vendedor = await prisma.vendedor.findFirst({
            where: { id: lead.vendedorId, ativo: true },
            select: { id: true, nome: true, telefone: true },
          });
        }
        if (!vendedor) {
          // Round-robin: quem foi atribuído há mais tempo (ou nunca) recebe o próximo lead novo
          vendedor = await prisma.vendedor.findFirst({
            where: { empresaId: lead.empresaId, ativo: true },
            orderBy: [{ ultimaAtribuicaoEm: "asc" }, { ordemChamada: "asc" }],
            select: { id: true, nome: true, telefone: true },
          });
          // Atribui ao lead para que pressão P24/P48/P72 funcione
          if (vendedor) {
            await Promise.all([
              prisma.lead.update({ where: { id: lead.id }, data: { vendedorId: vendedor.id } }),
              prisma.vendedor.update({ where: { id: vendedor.id }, data: { ultimaAtribuicaoEm: new Date() } }),
            ]).catch(() => null);
          }
        }
      }
      if (notificarGerente) {
        gerente = await prisma.vendedor.findFirst({
          where: { empresaId: lead.empresaId, ativo: true, cargo: "GERENTE" },
          select: { id: true, nome: true, telefone: true },
        });
      }
    }
  }

  return NextResponse.json({ ok: true, vendedor, gerente, aprendizados });
}
